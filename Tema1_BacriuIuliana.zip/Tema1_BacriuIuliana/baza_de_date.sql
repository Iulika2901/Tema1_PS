CREATE DATABASE IF NOT EXISTS gallery;
USE gallery;

CREATE TABLE Artist (
    artistID INT PRIMARY KEY AUTO_INCREMENT,
    artistName VARCHAR(100),
    birthDate DATE,
    birthPlace VARCHAR(100)
);

CREATE TABLE Paintings (
    PaintingID INT PRIMARY KEY AUTO_INCREMENT,
    artistID INT,                 
    Tipe VARCHAR(100),
    Pret INT,
    FOREIGN KEY (artistID) REFERENCES Artist(artistID) 
);

ALTER TABLE Artist ADD COLUMN image VARCHAR(256);
ALTER TABLE Paintings ADD COLUMN image VARCHAR(256);

drop table Paintings;

USE gallery;

CREATE TABLE Painting (
    paintingID INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    artistID INT,
    type VARCHAR(50),        
    price DOUBLE,            
    imagePath1 VARCHAR(255), 
    imagePath2 VARCHAR(255), 
    imagePath3 VARCHAR(255), 
    FOREIGN KEY (artistID) REFERENCES Artist(artistID) ON DELETE CASCADE
);

INSERT INTO Artist VALUES (7, 'Vincent van Gogh  v', '1853-03-03', 'Netherlands', '"C:\Users\Asus\OneDrive - Technical University of Cluj-Napoca\Desktop\fac3\sem2\Proiectare software\untitled\photos\portrait-of-leonardo-da-vinci-1452-1519-getty.avif"');
INSERT INTO Artist VALUES (6, 'Nicolae Grigorescu', '1500-04-04', 'Romania', '"C:\Users\Asus\OneDrive - Technical University of Cluj-Napoca\Desktop\fac3\sem2\Proiectare software\untitled\photos\portrait-of-leonardo-da-vinci-1452-1519-getty.avif"');

INSERT INTO Painting (title, artistID, type, price, imagePath1, imagePath2, imagePath3) 
VALUES ('Carul cu boiii', 3, 'pictura', 15.50, 
        'Leonardo_self.jpg',
         'Leonardo_self.jpg',
          'Leonardo_self.jpg');

select * from  Artist;

USE gallery;

ALTER TABLE Artist ADD COLUMN nationality VARCHAR(100);

ALTER TABLE Artist ADD COLUMN imagePath VARCHAR(255);


