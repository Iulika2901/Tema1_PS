package org.example;

import org.example.View.JavaFXGUI;
import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        Application.launch(JavaFXGUI.class, args);
    }
}

