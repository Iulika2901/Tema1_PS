package org.example.View;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.application.Platform;
import org.example.Model.Repository.ArtistRepository;
import org.example.Model.Repository.PaintingRepository;
import org.example.Model.Repository.Repository;
import org.example.Preseter.GalleryPresenter;
import org.example.Preseter.IGalleryGUI;

import java.util.List;

public class JavaFXGUI extends Application implements IGalleryGUI {
    private GalleryPresenter presenter;

    private ListView<String> artistListView;
    private ListView<String> paintingListView;

    private ImageView artistImageView = new ImageView();
    private ImageView paintingImageView1 = new ImageView();
    private ImageView paintingImageView2 = new ImageView();
    private ImageView paintingImageView3 = new ImageView();

    @Override
    public void start(Stage primaryStage) {

        artistListView = new ListView<>();
        artistListView.setPrefHeight(150);
        artistListView.setPrefWidth(450);

        artistImageView = new ImageView();
        artistImageView.setFitHeight(150);
        artistImageView.setFitWidth(150);
        artistImageView.setPreserveRatio(true);
        artistImageView.setStyle("-fx-border-color: gray;");

        HBox artistListAndImageBox = new HBox(15, artistListView, artistImageView);

        Button btnLoadArtists = new Button("Show All Artists");
        TextField searchArtistField = new TextField();
        searchArtistField.setPromptText("Enter artist name...");
        Button btnSearchArtist = new Button("Search Artist");
        Button btnDeleteArtist = new Button("Delete Selected Artist");
        btnDeleteArtist.setStyle("-fx-background-color: #ff6666; -fx-text-fill: white;");

        HBox artistTopBox = new HBox(10, btnLoadArtists, searchArtistField, btnSearchArtist, btnDeleteArtist);

        TextField addArtistName = new TextField(); addArtistName.setPromptText("Name"); addArtistName.setPrefWidth(120);
        TextField addArtistBDate = new TextField(); addArtistBDate.setPromptText("Birth Date"); addArtistBDate.setPrefWidth(90);
        TextField addArtistBPlace = new TextField(); addArtistBPlace.setPromptText("Birth Place"); addArtistBPlace.setPrefWidth(100);
        TextField addArtistNat = new TextField(); addArtistNat.setPromptText("Nationality"); addArtistNat.setPrefWidth(90);
        TextField addArtistImg = new TextField(); addArtistImg.setPromptText("Image (e.g., pic.jpg)"); addArtistImg.setPrefWidth(130);

        Button btnAddArtist = new Button("Add Artist");
        btnAddArtist.setStyle("-fx-background-color: #66cc66; -fx-text-fill: white;");

        HBox artistAddBox = new HBox(10, addArtistName, addArtistBDate, addArtistBPlace, addArtistNat, addArtistImg, btnAddArtist);

        VBox artistSection = new VBox(10, new Label("--- ARTISTS SECTION ---"), artistTopBox, artistAddBox, artistListAndImageBox);


        paintingListView = new ListView<>();
        paintingListView.setPrefHeight(150);
        paintingListView.setPrefWidth(400);

        paintingImageView1 = new ImageView(); paintingImageView1.setFitHeight(120); paintingImageView1.setFitWidth(120); paintingImageView1.setPreserveRatio(true);
        paintingImageView2 = new ImageView(); paintingImageView2.setFitHeight(120); paintingImageView2.setFitWidth(120); paintingImageView2.setPreserveRatio(true);
        paintingImageView3 = new ImageView(); paintingImageView3.setFitHeight(120); paintingImageView3.setFitWidth(120); paintingImageView3.setPreserveRatio(true);

        VBox imagesBox = new VBox(5, paintingImageView1, paintingImageView2, paintingImageView3);
        HBox paintingListAndImageBox = new HBox(15, paintingListView, imagesBox);

        Button btnLoadPaintings = new Button("Show All Paintings");
        TextField searchTitleField = new TextField(); searchTitleField.setPromptText("Search by title...");
        Button btnSearchTitle = new Button("Search Title");
        Button btnDeletePainting = new Button("Delete Selected Painting");
        btnDeletePainting.setStyle("-fx-background-color: #ff6666; -fx-text-fill: white;");

        HBox paintingTopBox = new HBox(10, btnLoadPaintings, searchTitleField, btnSearchTitle, btnDeletePainting);

        TextField addTitle = new TextField(); addTitle.setPromptText("Title");
        TextField addArtistId = new TextField(); addArtistId.setPromptText("Artist ID"); addArtistId.setPrefWidth(70);
        TextField addType = new TextField(); addType.setPromptText("Type"); addType.setPrefWidth(80);
        TextField addPrice = new TextField(); addPrice.setPromptText("Price"); addPrice.setPrefWidth(70);
        Button btnAddPainting = new Button("Add Painting");
        btnAddPainting.setStyle("-fx-background-color: #66cc66; -fx-text-fill: white;");

        HBox paintingAddBox = new HBox(10, addTitle, addArtistId, addType, addPrice, btnAddPainting);

        VBox paintingSection = new VBox(10, new Label("--- PAINTINGS SECTION ---"), paintingTopBox, paintingAddBox, paintingListAndImageBox);


        Repository baseRepo = new Repository();
        ArtistRepository artistRepo = new ArtistRepository(baseRepo);
        PaintingRepository paintingRepo = new PaintingRepository(baseRepo);
        this.presenter = new GalleryPresenter(this, artistRepo, paintingRepo);


        artistListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            presenter.onArtistSelected(newValue);
        });

        paintingListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            presenter.onPaintingSelected(newValue);
        });

        btnLoadArtists.setOnAction(e -> {
            searchArtistField.clear();
            presenter.loadAllArtists();
        });

        btnSearchArtist.setOnAction(e -> presenter.searchArtist(searchArtistField.getText()));
        btnDeleteArtist.setOnAction(e -> presenter.deleteArtist(artistListView.getSelectionModel().getSelectedItem()));

        btnAddArtist.setOnAction(e -> {
            presenter.addArtist(addArtistName.getText(), addArtistBDate.getText(), addArtistBPlace.getText(), addArtistNat.getText(), addArtistImg.getText());
            addArtistName.clear(); addArtistBDate.clear(); addArtistBPlace.clear(); addArtistNat.clear(); addArtistImg.clear();
        });

        btnLoadPaintings.setOnAction(e -> {
            searchTitleField.clear();
            presenter.loadAllPaintings();
        });

        btnSearchTitle.setOnAction(e -> presenter.searchPaintingByTitle(searchTitleField.getText()));
        btnDeletePainting.setOnAction(e -> presenter.deletePainting(paintingListView.getSelectionModel().getSelectedItem()));

        btnAddPainting.setOnAction(e -> {
            presenter.addPainting(addTitle.getText(), addArtistId.getText(), addType.getText(), addPrice.getText());
            addTitle.clear(); addArtistId.clear(); addType.clear(); addPrice.clear();
        });


        VBox mainLayout = new VBox(30, artistSection, paintingSection);
        mainLayout.setStyle("-fx-padding: 20px; -fx-font-size: 14px;");

        Scene scene = new Scene(mainLayout, 900, 750);

        primaryStage.setTitle("Art Gallery Management");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    @Override
    public void showMessage(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, message);
            alert.setTitle("Information");
            alert.setHeaderText(null);
            alert.show();
        });
    }

    @Override
    public void showError(String errorMessage) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR, errorMessage);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.show();
        });
    }

    @Override
    public void displayArtists(List<String> artistData) {
        artistListView.getItems().clear();
        if (artistData != null) artistListView.getItems().addAll(artistData);
    }

    @Override
    public void displayPaintings(List<String> paintingDataList) {
        paintingListView.getItems().clear();
        if (paintingDataList != null) paintingListView.getItems().addAll(paintingDataList);
    }

    @Override
    public void displayArtistDetails(String artistDetails, String imagePath, List<String> artistPaintings) {
    }

    @Override
    public void showArtistImage(String imagePath) {
        Platform.runLater(() -> {
            setImageSafely(artistImageView, imagePath);
        });
    }

    @Override
    public void showPaintingImages(String path1, String path2, String path3) {
        Platform.runLater(() -> {
            setImageSafely(paintingImageView1, path1);
            setImageSafely(paintingImageView2, path2);
            setImageSafely(paintingImageView3, path3);
        });
    }

    private void setImageSafely(ImageView targetImageView, String filename) {
        try {
            if (filename != null && !filename.trim().isEmpty() && !filename.equals("-")) {

                String resourcePath = "/photos/" + filename;
                java.net.URL imageUrl = getClass().getResource(resourcePath);

                if (imageUrl != null) {
                    Image img = new Image(imageUrl.toExternalForm(), true);
                    targetImageView.setImage(img);
                } else {
                    System.err.println("Image not found in resources: " + resourcePath);
                    targetImageView.setImage(null);
                }
            } else {
                targetImageView.setImage(null);
            }
        } catch (Exception e) {
            System.err.println("Error rendering image: " + e.getMessage());
            targetImageView.setImage(null);
        }
    }
}