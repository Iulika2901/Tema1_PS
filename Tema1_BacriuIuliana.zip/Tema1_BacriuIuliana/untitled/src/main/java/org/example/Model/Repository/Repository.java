package org.example.Model.Repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Repository {
    private static final String URL = "jdbc:mysql://localhost:3306/gallery";
    private static final String USER = "root";
    private static final String PASSWORD = "Romania@11";

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}