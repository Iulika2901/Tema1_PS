package org.example.Preseter;

import java.util.List;

public interface IGalleryGUI {
    void showMessage(String message);
    void showError(String errorMessage);

    void displayArtists(List<String> artistDataList);
    void displayArtistDetails(String artistDetails, String imagePath, List<String> artistPaintings);

    void showArtistImage(String imagePath);
    void showPaintingImages(String imagePath1, String imagePath2, String imagePath3);

    void displayPaintings(List<String> paintingDataList);
}