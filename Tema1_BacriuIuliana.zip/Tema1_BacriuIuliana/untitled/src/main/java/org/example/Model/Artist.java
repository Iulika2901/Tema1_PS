package org.example.Model;


public class Artist {
    private int artistId;
    private String name;
    private String birthDate;
    private String birthPlace;
    private String nationality;
    private String imagePath;

    public Artist() {}

    public Artist(int artistId, String name, String birthDate, String birthPlace) {
        this.artistId = artistId;
        this.name = name;
        this.birthDate = birthDate;
        this.birthPlace = birthPlace;
    }

    public Artist(int id, String name, String bDate, String bPlace, String nationality, String imagePath) {
    this.artistId = id;
    this.name = name;
    this.birthDate = bDate;
    this.birthPlace = bPlace;
   this.nationality = nationality;
   this.imagePath = imagePath;
    }

    public String getBirthPlace() {
        return birthPlace;
    }

    public int getArtistId() { return artistId; }
    public void setArtistId(int artistId) { this.artistId = artistId; }

    public String getName() { return name; }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public void setBirthPlace(String birthPlace) {
        this.birthPlace = birthPlace;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
    public int getId() {
        return artistId;
    }


    public void setName(String name) { this.name = name; }


}