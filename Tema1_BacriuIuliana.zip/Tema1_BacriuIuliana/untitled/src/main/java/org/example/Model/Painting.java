package org.example.Model;

public class Painting {
    private int id;
    private String title;
    private int artistId;
    private String type;
    private double price;
    private String imagePath1;
    private String imagePath2;
    private String imagePath3;

    public Painting(int id, String title, int artistId, String type, double price,
                    String imagePath1, String imagePath2, String imagePath3) {
        this.id = id;
        this.title = title;
        this.artistId = artistId;
        this.type = type;
        this.price = price;
        this.imagePath1 = imagePath1;
        this.imagePath2 = imagePath2;
        this.imagePath3 = imagePath3;
    }


    public int getId() { return id; }
    public String getTitle() { return title; }
    public int getArtistId() { return artistId; }
    public String getType() { return type; }
    public double getPrice() { return price; }
    public String getImagePath1() { return imagePath1; }
    public String getImagePath2() { return imagePath2; }
    public String getImagePath3() { return imagePath3; }
}