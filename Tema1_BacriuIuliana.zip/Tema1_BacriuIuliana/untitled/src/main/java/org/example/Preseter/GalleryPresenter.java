package org.example.Preseter;

import org.example.Model.Artist;
import org.example.Model.Painting;
import org.example.Model.Repository.ArtistRepository;
import org.example.Model.Repository.PaintingRepository;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class GalleryPresenter {
    private final IGalleryGUI view;
    private final ArtistRepository artistRepository;
    private final PaintingRepository paintingRepository;

    public GalleryPresenter(IGalleryGUI view, ArtistRepository artistRepository, PaintingRepository paintingRepository) {
        this.view = view;
        this.artistRepository = artistRepository;
        this.paintingRepository = paintingRepository;
    }

    public void loadAllArtists() {
        try {
            List<Artist> artists = artistRepository.getAllArtists();
            view.displayArtists(formatArtistDataForView(artists));
        } catch (SQLException e) {
            view.showError("Error loading artists from the database.");
        }
    }

    public void onArtistSelected(String selectedItemText) {
        if (selectedItemText == null || selectedItemText.trim().isEmpty()) return;

        try {
            int artistId = extractIdFromText(selectedItemText);
            Artist artist = artistRepository.getArtistById(artistId);
            if (artist != null) {
                view.showArtistImage(artist.getImagePath());
            }
        } catch (Exception e) {
            view.showError("Could not load the artist's image.");
        }
    }

    public void onPaintingSelected(String selectedItemText) {
        if (selectedItemText == null || selectedItemText.trim().isEmpty()) return;

        try {
            int paintingId = extractIdFromText(selectedItemText);
            Painting painting = paintingRepository.getPaintingById(paintingId);
            if (painting != null) {
                view.showPaintingImages(painting.getImagePath1(), painting.getImagePath2(), painting.getImagePath3());
            }
        } catch (Exception e) {
            view.showError("Could not load the artwork's image.");
        }
    }

    private int extractIdFromText(String text) {
        String searchString = "ID: ";
        int startIndex = text.indexOf(searchString) + searchString.length();
        int endIndex = text.indexOf(" |", startIndex);
        return Integer.parseInt(text.substring(startIndex, endIndex).trim());
    }

    public void addPainting(String title, String artistIdStr, String type, String priceStr) {
        try {
            int artistId = Integer.parseInt(artistIdStr);
            double price = Double.parseDouble(priceStr);

            if (title == null || title.trim().isEmpty()) {
                view.showError("The artwork title is mandatory!");
                return;
            }

            Painting newPainting = new Painting(0, title, artistId, type, price, "photo1.jpg", "-", "-");
            paintingRepository.addPainting(newPainting);

            view.showMessage("Artwork '" + title + "' was added successfully!");
            loadAllPaintings();

        } catch (NumberFormatException e) {
            view.showError("Artist ID and Price must be valid numbers!");
        } catch (SQLException e) {
            view.showError("Error saving to database: " + e.getMessage());
        }
    }

    public void deletePainting(String selectedItemText) {
        if (selectedItemText == null || selectedItemText.trim().isEmpty()) {
            view.showError("Please select an artwork from the list to delete!");
            return;
        }
        try {
            int paintingId = extractIdFromText(selectedItemText);
            paintingRepository.deletePainting(paintingId);
            view.showMessage("The artwork was deleted from the database!");
            loadAllPaintings();

        } catch (Exception e) {
            view.showError("Could not delete the artwork.");
        }
    }

    public void loadAllPaintings() {
        try {
            List<Painting> paintings = paintingRepository.getAllPaintingsSortedByArtist();
            view.displayPaintings(formatPaintingDataForView(paintings));
        } catch (SQLException e) {
            view.showError("Error loading artworks: " + e.getMessage());
        }
    }

    public void searchPaintingByTitle(String title) {
        if (title == null || title.trim().isEmpty()) {
            loadAllPaintings();
            return;
        }
        try {
            List<Painting> paintings = paintingRepository.searchByTitle(title);
            if (paintings.isEmpty()) {
                view.showMessage("No artwork found with the title: " + title);
                view.displayPaintings(new ArrayList<>());
            } else {
                view.displayPaintings(formatPaintingDataForView(paintings));
            }
        } catch (SQLException e) {
            view.showError("Error searching for the artwork.");
        }
    }

    public void deleteArtist(String selectedItemText) {
        if (selectedItemText == null || selectedItemText.trim().isEmpty()) {
            view.showError("Please select an artist from the list to delete!");
            return;
        }
        try {
            int artistId = extractIdFromText(selectedItemText);
            artistRepository.deleteArtist(artistId);
            view.showMessage("The artist was deleted from the database!");
            loadAllArtists();
        } catch (Exception e) {
            view.showError("Could not delete the artist. Maybe they have associated artworks?");
        }
    }

    private List<String> formatPaintingDataForView(List<Painting> paintings) {
        return paintings.stream().map(p -> {
            String imgs = String.format("[Images: %s, %s, %s]",
                    p.getImagePath1(),
                    p.getImagePath2() != null ? p.getImagePath2() : "-",
                    p.getImagePath3() != null ? p.getImagePath3() : "-");

            return String.format("ID: %d | Artist ID: %d | Title: %s | Type: %s | Price: %.2f | %s",
                    p.getId(), p.getArtistId(), p.getTitle(), p.getType(), p.getPrice(), imgs);
        }).collect(Collectors.toList());
    }

    public void searchArtist(String name) {
        if (name == null || name.trim().isEmpty()) {
            loadAllArtists();
            return;
        }
        try {
            List<Artist> artists = artistRepository.searchArtistsByName(name);
            view.displayArtists(formatArtistDataForView(artists));
        } catch (SQLException e) {
            view.showError("Error searching for the artist.");
        }
    }

    public void addArtist(String name, String bDate, String bPlace, String nationality, String imagePath) {
        try {
            if (name == null || name.isEmpty()) {
                view.showError("The artist's name is mandatory!");
                return;
            }
            Artist newArtist = new Artist(0, name, bDate, bPlace, nationality, imagePath);
            artistRepository.addArtist(newArtist);
            view.showMessage("Artist " + name + " was added successfully!");
            loadAllArtists();
        } catch (SQLException e) {
            view.showError("Error saving the artist.");
        }
    }

    private List<String> formatArtistDataForView(List<Artist> artists) {
        return artists.stream()
                .map(a -> String.format("ID: %d | Name: %s | Nationality: %s",
                        a.getId(), a.getName(), a.getNationality()))
                .collect(Collectors.toList());
    }
}