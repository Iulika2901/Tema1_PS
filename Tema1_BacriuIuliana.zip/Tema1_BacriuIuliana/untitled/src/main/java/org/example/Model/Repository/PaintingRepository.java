package org.example.Model.Repository;

import org.example.Model.Painting;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PaintingRepository {
    private final Repository repository;

    public PaintingRepository(Repository repository) {
        this.repository = repository;
    }

    public void addPainting(Painting p) throws SQLException {
        String sql = "INSERT INTO Painting (title, artistID, type, price, imagePath1, imagePath2, imagePath3) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = repository.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, p.getTitle());
            pstmt.setInt(2, p.getArtistId());
            pstmt.setString(3, p.getType());
            pstmt.setDouble(4, p.getPrice());
            pstmt.setString(5, p.getImagePath1());
            pstmt.setString(6, p.getImagePath2());
            pstmt.setString(7, p.getImagePath3());
            pstmt.executeUpdate();
        }
    }

    public List<Painting> getAllPaintingsSortedByArtist() throws SQLException {
        String sql = "SELECT * FROM Painting ORDER BY artistID ASC";
        return executeQueryAndGetList(sql);
    }

    public List<Painting> searchByTitle(String title) throws SQLException {
        List<Painting> list = new ArrayList<>();
        String sql = "SELECT * FROM Painting WHERE title LIKE ?";
        try (Connection conn = repository.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, "%" + title + "%");
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToPainting(rs));
                }
            }
        }
        return list;
    }

     public List<Painting> filterByArtist(int artistId) throws SQLException {
        String sql = "SELECT * FROM Painting WHERE artistID = " + artistId;
        return executeQueryAndGetList(sql);
    }

     public List<Painting> filterByType(String type) throws SQLException {
        List<Painting> list = new ArrayList<>();
        String sql = "SELECT * FROM Painting WHERE type = ?";
        try (Connection conn = repository.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, type);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToPainting(rs));
                }
            }
        }
        return list;
    }

    public List<Painting> filterByMaxPrice(double maxPrice) throws SQLException {
        String sql = "SELECT * FROM Painting WHERE price <= " + maxPrice;
        return executeQueryAndGetList(sql);
    }

     public void updatePainting(Painting p) throws SQLException {
        String sql = "UPDATE Painting SET title=?, artistID=?, type=?, price=?, imagePath1=?, imagePath2=?, imagePath3=? WHERE paintingID=?";
        try (Connection conn = repository.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, p.getTitle());
            pstmt.setInt(2, p.getArtistId());
            pstmt.setString(3, p.getType());
            pstmt.setDouble(4, p.getPrice());
            pstmt.setString(5, p.getImagePath1());
            pstmt.setString(6, p.getImagePath2());
            pstmt.setString(7, p.getImagePath3());
            pstmt.setInt(8, p.getId());
            pstmt.executeUpdate();
        }
    }

     public void deletePainting(int id) throws SQLException {
        String sql = "DELETE FROM Painting WHERE paintingID = ?";
        try (Connection conn = repository.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

     private List<Painting> executeQueryAndGetList(String sql) throws SQLException {
        List<Painting> list = new ArrayList<>();
        try (Connection conn = repository.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToPainting(rs));
            }
        }
        return list;
    }

    public Painting getPaintingById(int id) throws SQLException {
        String sql = "SELECT * FROM Painting WHERE paintingID = ?";
        try (Connection conn = repository.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToPainting(rs);
                }
            }
        }
        return null;
    }

    private Painting mapResultSetToPainting(ResultSet rs) throws SQLException {
        return new Painting(
                rs.getInt("paintingID"),
                rs.getString("title"),
                rs.getInt("artistID"),
                rs.getString("type"),
                rs.getDouble("price"),
                rs.getString("imagePath1"),
                rs.getString("imagePath2"),
                rs.getString("imagePath3")
        );
    }
}