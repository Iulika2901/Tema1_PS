package org.example.Model.Repository;

import org.example.Model.Artist;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ArtistRepository {
    private final Repository repository;

    public ArtistRepository(Repository repository) {
        this.repository = repository;
    }

    public void addArtist(Artist artist) throws SQLException {
        String sql = "INSERT INTO Artist (artistName, birthDate, birthPlace, nationality, imagePath) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = repository.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, artist.getName());
            pstmt.setString(2, artist.getBirthDate());
            pstmt.setString(3, artist.getBirthPlace());
            pstmt.setString(4, artist.getNationality());
            pstmt.setString(5, artist.getImagePath());

            pstmt.executeUpdate();
        }
    }

    public List<Artist> getAllArtists() throws SQLException {
        List<Artist> artistsList = new ArrayList<>();
        String sql = "SELECT * FROM Artist";
        try (Connection conn = repository.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                artistsList.add(mapResultSetToArtist(rs));
            }
        }
        return artistsList;
    }

     public List<Artist> searchArtistsByName(String name) throws SQLException {
        List<Artist> artistsList = new ArrayList<>();
        String sql = "SELECT * FROM Artist WHERE artistName LIKE ?";
        try (Connection conn = repository.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, "%" + name + "%");
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    artistsList.add(mapResultSetToArtist(rs));
                }
            }
        }
        return artistsList;
    }

     public void updateArtist(Artist artist) throws SQLException {
        String sql = "UPDATE Artist SET artistName = ?, birthDate = ?, birthPlace = ?, nationality = ?, imagePath = ? WHERE artistID = ?";
        try (Connection conn = repository.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, artist.getName());
            pstmt.setString(2, artist.getBirthDate());
            pstmt.setInt(6, artist.getId());

            pstmt.executeUpdate();
        }
    }

    public Artist getArtistById(int id) throws SQLException {
        String sql = "SELECT * FROM Artist WHERE artistID = ?";
        try (Connection conn = repository.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToArtist(rs);
                }
            }
        }
        return null;
    }

    public void deleteArtist(int artistId) throws SQLException {
        String sql = "DELETE FROM Artist WHERE artistID = ?";
        try (Connection conn = repository.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, artistId);
            pstmt.executeUpdate();
        }
    }

     private Artist mapResultSetToArtist(ResultSet rs) throws SQLException {
        int id = rs.getInt("artistID");
        String name = rs.getString("artistName");
        String bDate = rs.getString("birthDate");
        String bPlace = rs.getString("birthPlace");
        String nationality = rs.getString("nationality");
        String imagePath = rs.getString("imagePath");

        return new Artist(id, name, bDate, bPlace, nationality, imagePath);
    }
}